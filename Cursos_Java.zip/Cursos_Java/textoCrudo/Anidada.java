public class Anidada{
 public static void main(String args[]){
 operacion =1;
 numUno =4;
 numDos=2;
 resultado=0;

System.out.println("Seleccionar 1 para suma, dos para resta, tres para multiplicacion y 4 para division"); 

 if(operacion=1){
 System.out.println("El resultado de la suma es" numUno + numDos);
 } else 
  if(operacion=2){
 System.out.println("El resultado de la resta es" numUno - numDos);
 } else 
 if(operacion=3){
 System.out.println("El resultado de la multiplicaicon es" numUno * numDos);
 } else 
   if(operacion=1){
 System.out.println("El resultado de la division es" numUno / numDos);
 } else 
 
 {System.out.println("El valor de la operacion es incorrecto");}


}
}