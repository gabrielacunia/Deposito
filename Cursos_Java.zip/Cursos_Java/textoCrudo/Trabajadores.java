  import java.util.Scanner; 

public class Suma{
 public static void main(String args[]){
System.out.println("");
 numUno = in.nextInt();




}
}