/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;

/**
 *
 * @author Pablo
 */
public class Menu {
    private String opcionUno = "1 - Cargar País";
    private String opcionDos = "2 - Mostrar países cargados";
    private String opcionTres = "3 - Buscar País";
    private String opcionCuatro = "4 - Eliminar País";
    private String opcionCinco = "5 - Salir";

    public String getOpcionUno() {
        return opcionUno;
    }

    public void setOpcionUno(String opcionUno) {
        this.opcionUno = opcionUno;
    }

    public String getOpcionDos() {
        return opcionDos;
    }

    public void setOpcionDos(String opcionDos) {
        this.opcionDos = opcionDos;
    }

    public String getOpcionTres() {
        return opcionTres;
    }

    public void setOpcionTres(String opcionTres) {
        this.opcionTres = opcionTres;
    }

    public String getOpcionCuatro() {
        return opcionCuatro;
    }

    public void setOpcionCuatro(String opcionCuatro) {
        this.opcionCuatro = opcionCuatro;
    } 

    public String getOpcionCinco() {
        return opcionCinco;
    }

    public void setOpcionCinco(String opcionCinco) {
        this.opcionCinco = opcionCinco;
    }
}
